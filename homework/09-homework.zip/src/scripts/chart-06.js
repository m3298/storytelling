import * as d3 from 'd3'

// Set up margin/height/width

// I'll give you the container
const container = d3.select('#chart-06')

// Create your scales

// Create a d3.line function that uses your scales

// Read in your data

// Build your ready function that draws lines, axes, etc
