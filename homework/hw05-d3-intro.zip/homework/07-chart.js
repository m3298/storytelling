(function() {

  // Delete this line, redo it.
  var svg = d3.select("#chart7").append("svg")

  // DO NOT CHANGE THIS SECTION
  svg.append("rect")
    .attr("height", 100)
    .attr("width", 300)
    .attr("x", 0)
    .attr("y", 0)
  // DO NOT CHANGE THIS SECTION
})()