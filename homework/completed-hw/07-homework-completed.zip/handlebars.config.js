module.exports = {
  data: 'metadata',
  helpers: 'src/scripts/helpers',
  partials: 'src/html'
}
