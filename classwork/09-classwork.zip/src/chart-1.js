import * as d3 from 'd3'

var margin = { top: 30, left: 30, right: 100, bottom: 30 }

var height = 300 - margin.top - margin.bottom

var width = 700 - margin.left - margin.right

var svg = d3
  .select('#chart-1')
  .append('svg')
  .attr('height', height + margin.top + margin.bottom)
  .attr('width', width + margin.left + margin.right)
  .append('g')
  .attr('transform', 'translate(' + margin.left + ',' + margin.top + ')')

// Create our scales
var xPositionScale = d3
  .scaleLinear()
  .domain([1, 12])
  .range([0, width])
var yPositionScale = d3
  .scaleLinear()
  .domain([20, 100])
  .range([height, 0])

// Create a line generator
// This explains how to compute
// the points that make up the line

// Read in files
d3.csv(require('./all-temps.csv'))
  .then(ready)
  .catch(err => {
    console.log(err)
  })

function ready(datapoints) {
  // Draw the lines

  // Draw the circles
  svg
    .selectAll('.temp-circle')
    .data(datapoints)
    .enter()
    .append('circle')
    .attr('class', 'temp-circle')
    .attr('r', 3)
    .attr('cx', function(d) {
      return xPositionScale(d.month)
    })
    .attr('cy', function(d) {
      return yPositionScale(d.high)
    })

  var xAxis = d3.axisBottom(xPositionScale)
  svg
    .append('g')
    .attr('class', 'axis x-axis')
    .attr('transform', 'translate(0,' + height + ')')
    .call(xAxis)

  var yAxis = d3.axisLeft(yPositionScale)
  svg
    .append('g')
    .attr('class', 'axis y-axis')
    .call(yAxis)
}
