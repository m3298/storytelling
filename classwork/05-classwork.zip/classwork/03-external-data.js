(function () {

  var width = 800,
      height = 800;

  // Create the SVG



  // Read in some external data. When we're done, run the function 'ready'



  // This is 'ready':
  // it receives datapoints, our newly-read-in data
  function ready(datapoints) {
    // Can we look at our data?

    // d3 code goes here


    // Always cut and paste the code for the axes!

  }

})()