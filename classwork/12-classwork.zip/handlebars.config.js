module.exports = {
  data: 'metadata',
  helpers: 'src/scripts/helpers',
  partials: 'src/html',
  layouts: 'src/html/layouts'
}
